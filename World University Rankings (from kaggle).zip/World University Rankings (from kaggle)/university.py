import math

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import seaborn as sns
'''
#calculate Correlation_coefficient
'''
def Correlation_coefficient(date):

    df = date.copy()
    y = df.iloc[:,0]
    features_name = list(df.columns[1:])
    r = {}
    for feature in features_name:

        x = df[feature]
        r[feature] = np.corrcoef(x,y)

    return r
'''
# remove outlier
'''
def remove_outlier(data,feature,n ): #n是一个参数 median absolute deviation 中位值偏差法去除离群点

    df = data[feature]
    median = np.median(df)  # 中位数
    deviations = abs(df - median)
    mad = np.median(deviations)

    remove_idx = np.where(abs(df - median) > n * mad)
    new_data = data.drop(data.index[remove_idx])
    return new_data

'''
#model
'''
class LinearRegression_numpy(object):

    def __init__(self,features_name,target):

        self.features_name = features_name
        self.target = target
        self.b = np.array([])  # b是系数矩阵，是最后要求的数据

    #training
    def fit(self,data):
        df = data.copy()
        y = df[target].values
        y = y.T
        x = df[features_name].values
        x = np.insert(x, 0, 1, axis=1) # 0 axis = 1 代表 0列插入， 1 代表全是1

        b = np.linalg.inv(x.T @ x) @ x.T @ y
        self.b = b.reshape(len(b),1)

    # Calculate predicted value
    def predict(self,data):

        #计算预测值
        x = data[features_name].values
        x = np.insert(x, 0, 1, axis=1)
        y_hat = x @ self.b

        y_real = data[target].values
        y_real = y_real.reshape(len(y_real),1)
        y_mean = np.mean(y_real)

        self.rmse(y_real,y_hat)
        self.coefficient_of_determination(y_real,y_hat,y_mean)

    # calculate RMSE
    def rmse(self,y_real,y_hat):

        err = y_real - y_hat
        err = err ** 2
        RMSE = np.sum(err)/len(y_real) * 1.0
        RMSE = math.sqrt(RMSE)

        print('RMSE value is',RMSE)


    #calculate coefficient_of_determination
    def coefficient_of_determination(self,y_real,y_hat,y_mean):

        err1 = y_real - y_hat
        err1 = err1 ** 2
        err2 = y_real - y_mean
        err2 = err2 ** 2

        R2 = 1 - np.sum(err1)/np.sum(err2) * 1.0

        print('R2 value is ',R2)

'''
#Read the data and remove Nan
#读取数据，去掉Nan
'''
data_df = pd.read_csv('./cwurData.csv')  # 读入 csv 文件为 pandas 的 DataFrame
data_df = data_df.dropna()  # 舍去包含 NaN 的 row, 去掉了前两百行



'''
# Put 'score' in column 0
# 把score放到第0列
'''
target = 'score'
colums = data_df.columns.tolist()   # 把label放到第0列
for i in range(len(colums)):
    if colums[i] == target:
        colums[i], colums[0] = colums[0],colums[i]
df = data_df[colums]
#print(df)
'''
# Observe the data and discard some useless columns and non-numeric columns
# 观察数据, 舍去一些无用列和非数值列
'''
drop_features = ['world_rank','region','year','institution','national_rank']          # 需要舍去的特征列
df = df.drop(columns=drop_features)  # 舍去特征列
r = Correlation_coefficient(df)
'''
#remove outlier
# 去除离群点
'''
features_name = list(df.columns[1:])
for feature in features_name:
    df = remove_outlier(df,feature,30)
'''
# Divide the data set
# 划分数据集
'''
RANDOM_SEED = 42
train_df, test_df = train_test_split(df, test_size=0.2, random_state=RANDOM_SEED)

'''
#training and prediction
#训练和预测
'''
linerregression = LinearRegression_numpy(features_name,target)
linerregression.fit(train_df)
linerregression.predict(test_df)




'''
#Data visualization, based on sklearn
#数据可视化，基于sklearn
'''

feature_cols = ['quality_of_faculty', 'publications', 'citations', 'alumni_employment',
                'influence', 'quality_of_education', 'broad_impact', 'patents']
all_y = data_df['score'].values
all_x = data_df[feature_cols].values
x_train, x_test, y_train, y_test = train_test_split(all_x, all_y, test_size=0.2, random_state=2020)

LR = LinearRegression()  # 线性回归模型
LR.fit(x_train, y_train)  # 在训练集上训练
p_test = LR.predict(x_test)  # 在测试集上预测，获得预测值
test_error = p_test - y_test  # 预测误差
test_rmse = (test_error**2).mean()**0.5  # 计算 RMSE
print('rmse: {:.4}'.format(test_rmse))

sns.set()
sns.barplot(x=LR.coef_, y=feature_cols)
plt.show()








