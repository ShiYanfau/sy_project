import numpy as np
import os

from PIL import Image
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns


'''

# Read the image library
# 读取图片库
'''


def read_data(path, max_num=-1):
    data, label = list(), list()
    for root, dirs, files in os.walk(path):  # 遍历所有文件
        if len(dirs) == 0:  # 到达包含图片的文件夹
            y = root.split(os.path.sep)[-1]  # 文件夹名字（label）
            file_lst = files[:max_num] if max_num > 0 else files
            for f in file_lst:
                img = Image.open(os.path.join(root, f))
                data.append(np.array(img).reshape(-1))  # reshape 成一行作为输入向量
                label.append(y)
    return np.array(data), np.array(label)
'''

#simple test
#简单测试
'''


img = Image.open('data/train/0/4-3.jpg')  # 打开图片
img.show()

pixels = np.array(img)  # 转化为 numpy 矩阵
print(pixels.shape)

'''

#Divide the data set
#划分数据集
'''


PREFIX = './data/'
x_train, y_train = read_data(os.path.join(PREFIX, 'train'))
#print(x_train.shape)
x_test, y_test = read_data(os.path.join(PREFIX, 'test'))
#print(x_test.shape)



clf = KNeighborsClassifier()
clf.fit(x_train, y_train)  # 记录训练数据
p_test = clf.predict(x_test)  # 预测测试图片
accuracy = accuracy_score(p_test, y_test)  # 计算准确率
print('accuracy: {:<.4f}'.format(accuracy))

'''

#The influence of the value of K
# K 的影响
'''

sns.set()

k_range = range(1, 10)
acc_lst = list()
for k in k_range:  # 遍历邻居的个数 k
    clf = KNeighborsClassifier(k)
    clf.fit(x_train, y_train)  # 记录训练数据
    p_test = clf.predict(x_test)  # 预测测试图片
    accuracy = accuracy_score(p_test, y_test)  # 计算准确率
    acc_lst.append(accuracy)
    print('K: {}, accuracy: {:<.4f}'.format(k, accuracy))

plt.plot(k_range, acc_lst)  # 画图
plt.xlabel('K')
plt.ylabel('Accuracy')
plt.show()

'''

# Whether to weight and the impact of distance measurement
# 是否加权以及距离度量的影响
'''

for weight in ['uniform', 'distance']:
    for metric in ['euclidean', 'manhattan', 'chebyshev', 'minkowski']:
        clf = KNeighborsClassifier(n_neighbors=2, weights=weight, metric=metric)
        clf.fit(x_train, y_train)
        p_test = clf.predict(x_test)
        accuracy = accuracy_score(p_test, y_test)
        acc_lst.append(accuracy)
        print('weight: {}, metric: {}, accuracy: {:<.4f}'.format(weight, metric, accuracy))


'''
#The impact of training set size
# 训练集大小的影响
'''

train_range = [10, 50, 100, 500, 1000, 2000]
acc_lst = list()
for train_num in train_range:
    x_train, y_train = read_data(os.path.join(PREFIX, 'train'), max_num=train_num)
    clf = KNeighborsClassifier(2)  # k = 2
    clf.fit(x_train, y_train)
    p_test = clf.predict(x_test)
    accuracy = accuracy_score(p_test, y_test)
    acc_lst.append(accuracy)
    print('train: {}, accuracy: {:<.4f}'.format(train_num, accuracy))

plt.plot(train_range, acc_lst)
plt.xlabel('# train')
plt.ylabel('Accuracy')
plt.show()

