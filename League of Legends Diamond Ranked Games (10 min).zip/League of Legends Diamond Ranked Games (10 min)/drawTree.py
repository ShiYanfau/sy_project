import networkx as nx
import matplotlib.pyplot as plt
import numpy as np


# Step 1: Recursive function to build the graph from the tree structure
def build_graph(node, graph, parent_name=None, parent_value=None):
    feature, children_dict, arr = node
    node_name = feature + "\n" + str(arr)

    # Add the current node to the graph
    graph.add_node(node_name)

    # If there's a parent, connect the current node to the parent
    if parent_name:
        edge_label = parent_value
        graph.add_edge(parent_name, node_name, label=edge_label)

    # For each child, recursively add its nodes and edges to the graph
    for value, child in children_dict.items():
        if isinstance(child, tuple):  # Check if the child is a node and not a leaf
            build_graph(child, graph, node_name, value)

    return graph


# Step 2: Function to plot the tree using networkx and matplotlib
def plot_tree(tree):
    # Initialize a directed graph
    G = build_graph(tree, nx.DiGraph())

    # Get positions for the nodes in G using a spring layout
    pos = nx.spring_layout(G)

    # Extract edge labels from the graph
    labels = nx.get_edge_attributes(G, 'label')

    # Plot the graph
    plt.figure(figsize=(10, 6))
    nx.draw(G, pos, with_labels=True, node_size=4000, node_color="skyblue", font_size=10, font_weight='bold')
    nx.draw_networkx_edge_labels(G, pos, edge_labels=labels, font_size=10)
    plt.show()


# Given tree structure
tree = ('windy', {False: ('humility', {'high': ('temp', {'hot': ('outlook', {'sunny': [3, 0], 'overcast': [0, 2]}, [3, 2]), 'mild': ('outlook', {'rainy': [0, 2], 'sunny': [2, 0]}, [2, 2])}, [5, 4]), 'normal': [0, 8]}, [ 5, 12]), True: ('humility', {'high': ('temp', {'hot': [3, 0], 'mild': ('outlook', {'overcast': [0, 2], 'rainy': [2, 0]}, [2, 2])}, [5, 2]), 'normal': ('temp', {'cool': ('outlook', {'rainy': [2, 0], 'overcast': [0, 2]}, [2, 2]), 'mild': [0, 2]}, [2, 4])}, [7, 6])}, [12, 18])
# Plot the tree
plot_tree(tree)
